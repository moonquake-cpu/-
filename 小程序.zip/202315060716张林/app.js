App({
  globalData: {
    userInfo: null,
    foodList: [],
    currentAudio: null
  },
  onLaunch() {
    const foodList = [
      { id: 1, name: '红烧牛肉面', price: '¥12', rate: 4.5, canteen: '一食堂', tag: '中餐', desc: '浓郁牛骨汤底，大块牛肉', emoji: '🍜' },
      { id: 2, name: '黑椒牛柳意面', price: '¥16', rate: 4.7, canteen: '西餐厅', tag: '西餐', desc: '现炒牛柳搭配黑椒酱汁', emoji: '🍝' },
      { id: 3, name: '鲜榨芒果冰', price: '¥8', rate: 4.6, canteen: '饮品吧', tag: '饮品', desc: '新鲜芒果现榨，清凉解暑', emoji: '🥤' },
      { id: 4, name: '麻辣香锅', price: '¥18', rate: 4.8, canteen: '二食堂', tag: '中餐', desc: '自选食材，麻辣鲜香', emoji: '🌶️' },
      { id: 5, name: '日式豚骨拉面', price: '¥15', rate: 4.4, canteen: '三食堂', tag: '日料', desc: '浓郁猪骨汤，溏心蛋', emoji: '🍜' },
      { id: 6, name: '芝士焗饭', price: '¥14', rate: 4.5, canteen: '西餐厅', tag: '西餐', desc: '拉丝芝士搭配培根蘑菇', emoji: '🧀' }
    ]
    this.globalData.foodList = foodList
  }
})
