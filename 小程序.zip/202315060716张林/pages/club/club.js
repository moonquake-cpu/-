const app = getApp()

Page({
  data: {
    clubs: [
      { id: 1, name: '美食侦探社', members: 128, desc: '每周探店测评，分享校园美食第一手体验', avatar: '🔍', bgColor: '#FFEAA7', accent: '#D35400', events: ['川菜馆探店', '甜品DIY活动', '校园美食地图制作'] },
      { id: 2, name: '烘焙爱好者协会', members: 86, desc: '一起做蛋糕、面包、甜点，分享烘焙的快乐', avatar: '🧁', bgColor: '#F8C291', accent: '#B71540', events: ['戚风蛋糕教学', '中秋月饼制作', '圣诞姜饼屋比赛'] },
      { id: 3, name: '吃货联盟', members: 215, desc: '校内最大美食社团，组织美食节和团购活动', avatar: '🍔', bgColor: '#82CCDD', accent: '#1B1464', events: ['校园美食节', '食堂菜品投票', '美食摄影大赛'] }
    ],
    currentClubIndex: 0,
    showFullDesc: false
  },

  // ===== 切换社团 =====
  switchClub(e) {
    const index = e.currentTarget.dataset.index
    this.setData({ currentClubIndex: index, showFullDesc: false })
    const animation = wx.createAnimation({
      duration: 300,
      timingFunction: 'ease-out'
    })
    animation.scale(1.05).step()
    animation.scale(1).step()
    this.setData({ clubAnimation: animation.export() })
  },

  // ===== 展开/收起描述 =====
  toggleDesc() {
    this.setData({ showFullDesc: !this.data.showFullDesc })
  },

  // ===== 报名活动 - 交互API =====
  onJoinEvent(e) {
    const eventName = e.currentTarget.dataset.event
    wx.showModal({
      title: '报名确认',
      content: `确定要报名参加"${eventName}"吗？`,
      success: (res) => {
        if (res.confirm) {
          wx.showLoading({ title: '提交中...' })
          setTimeout(() => {
            wx.hideLoading()
            wx.showToast({ title: '报名成功！', icon: 'success' })
          }, 1000)
        }
      }
    })
  },

  // ===== 加入社团 =====
  onJoinClub() {
    const club = this.data.clubs[this.data.currentClubIndex]
    wx.showModal({
      title: `加入${club.name}`,
      content: `确定要申请加入"${club.name}"吗？`,
      success: (res) => {
        if (res.confirm) {
          wx.showToast({ title: `已申请加入${club.name}`, icon: 'success' })
        }
      }
    })
  },

  // ===== 分享API =====
  onShareAppMessage() {
    const club = this.data.clubs[this.data.currentClubIndex]
    return {
      title: `快来加入${club.name}！`,
      path: '/pages/club/club'
    }
  },

  // ===== 路由API =====
  goToHome() {
    wx.switchTab({ url: '/pages/index/index' })
  }
})
