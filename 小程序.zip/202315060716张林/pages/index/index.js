const app = getApp()

Page({
  data: {
    banners: [
      { id: 1, icon: '🍜', text: '新菜品上线，尝鲜有礼' },
      { id: 2, icon: '🎉', text: '美食节火热进行中' },
      { id: 3, icon: '🥤', text: '夏日特饮第二杯半价' }
    ],
    categories: [
      { id: 1, name: '中餐', icon: '🍚' },
      { id: 2, name: '西餐', icon: '🍝' },
      { id: 3, name: '饮品', icon: '🥤' },
      { id: 4, name: '日料', icon: '🍣' },
      { id: 5, name: '甜品', icon: '🍰' },
      { id: 6, name: '小吃', icon: '🌮' }
    ],
    foodList: [],
    filteredFoods: [],
    searchKeyword: '',
    tabList: ['全部', '中餐', '西餐', '饮品', '日料', '甜品', '小吃'],
    activeTab: '全部',
    userName: '美食探索者',
    animationData: {},
    currentSwiperIndex: 0
  },

  onLoad() {
    this.setData({
      foodList: app.globalData.foodList,
      filteredFoods: app.globalData.foodList
    })
    this.filterByTab('全部')
  },

  onShow() {
    this.fadeInAnimation()
  },

  // ===== 搜索功能（数据绑定 + JavaScript） =====
  onSearchInput(e) {
    const keyword = e.detail.value.toLowerCase()
    this.setData({ searchKeyword: keyword })
    this.filterFoods(keyword)
  },

  filterFoods(keyword) {
    if (!keyword.trim()) {
      this.setData({ filteredFoods: this.data.foodList })
      return
    }
    const filtered = this.data.foodList.filter(item =>
      item.name.toLowerCase().includes(keyword) ||
      item.canteen.toLowerCase().includes(keyword) ||
      item.tag.toLowerCase().includes(keyword)
    )
    this.setData({ filteredFoods: filtered })
    if (filtered.length === 0) {
      wx.showToast({ title: '未找到相关美食', icon: 'none' })
    }
  },

  // ===== 今日推荐选项卡点击 =====
  onTabTap(e) {
    const tab = e.currentTarget.dataset.tab
    this.setData({ activeTab: tab, searchKeyword: '' })
    this.filterByTab(tab)
  },

  // ===== 按选项卡过滤 =====
  filterByTab(tab) {
    if (tab === '全部') {
      this.setData({ filteredFoods: this.data.foodList })
      return
    }
    const filtered = this.data.foodList.filter(f => f.tag === tab)
    this.setData({ filteredFoods: filtered })
  },

  // ===== 跳转到推荐详情子页 =====
  goToDetail() {
    wx.navigateTo({
      url: '/pages/recommend-detail/recommend-detail'
    })
  },

  // ===== 分类导航点击 =====
  onCategoryTap(e) {
    const tag = e.currentTarget.dataset.tag
    this.setData({ searchKeyword: tag })
    this.filterFoods(tag)
    wx.showToast({ title: `查看${tag}类美食`, icon: 'none' })
  },

  // ===== 点击菜品 - 跳转详情子页 =====
  onFoodTap(e) {
    const food = e.currentTarget.dataset.food
    wx.navigateTo({
      url: `/pages/food-detail/food-detail?id=${food.id}&name=${food.name}&price=${food.price}&rate=${food.rate}&canteen=${food.canteen}&tag=${food.tag}&desc=${food.desc}&emoji=${food.emoji}`
    })
  },

  // ===== 音频API =====
  playAudio(food) {
    const audio = wx.createInnerAudioContext()
    audio.autoplay = true
    audio.src = ''
    audio.onError(() => {
      wx.showToast({ title: `🎵 推荐：${food.name}，${food.desc}`, icon: 'none', duration: 3000 })
    })
    audio.onEnded(() => { audio.destroy() })
    this.audio = audio
  },

  // ===== 动画API：淡入动画 =====
  fadeInAnimation() {
    const animation = wx.createAnimation({
      duration: 600,
      timingFunction: 'ease',
    })
    animation.opacity(1).translateY(0).step()
    this.setData({ animationData: animation.export() })
  },

  // ===== 轮播图切换 =====
  onSwiperChange(e) {
    this.setData({ currentSwiperIndex: e.detail.current })
  },

  // ===== 媒体API =====
  onUploadImage() {
    wx.chooseImage({
      count: 1,
      sizeType: ['compressed'],
      sourceType: ['camera', 'album'],
      success: (res) => {
        wx.showToast({ title: '上传成功！', icon: 'success' })
      },
      fail: () => {
        wx.showToast({ title: '已取消或设备不支持', icon: 'none' })
      }
    })
  },

  // ===== 路由API =====
  goToRecommend() {
    wx.switchTab({ url: '/pages/recommend/recommend' })
  },

  // ===== 个人信息点击 =====
  onUserTap() {
    wx.showActionSheet({
      itemList: ['我的收藏', '我的评价', '上传美食图片'],
      success: (res) => {
        if (res.tapIndex === 2) this.onUploadImage()
        else if (res.tapIndex === 0) wx.showToast({ title: '收藏功能开发中', icon: 'none' })
        else if (res.tapIndex === 1) wx.showToast({ title: '评价功能开发中', icon: 'none' })
      }
    })
  },

  onUnload() {
    if (this.audio) { this.audio.destroy() }
  }
})
