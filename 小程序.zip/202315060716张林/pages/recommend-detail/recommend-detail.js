const app = getApp()

Page({
  data: {
    // 今日精选（每日可轮换）
    dailyPicks: [],
    // 完整列表
    foodList: [],
    displayList: [],
    // 筛选
    selectedTag: '全部',
    tagList: ['全部', '中餐', '西餐', '饮品', '日料', '甜品', '小吃'],
    // 排序
    sortBy: 'rate',
    sortLabel: '按评分排序',
    // 状态
    loading: false
  },

  onLoad() {
    const rawList = app.globalData.foodList || []
    // 给每个菜品添加推荐理由
    const reasons = [
      '主厨特制配方，回头客最多',
      '精选进口食材，口感出众',
      '每日鲜榨，清爽解腻首选',
      '自选搭配，满足个性口味',
      '浓郁汤底熬制6小时以上',
      '现点现做，芝士分量超足'
    ]
    const enriched = rawList.map((item, i) => ({
      ...item,
      reason: reasons[i % reasons.length]
    }))
    // 今日精选按评分 top 3
    const sorted = [...enriched].sort((a, b) => b.rate - a.rate)
    const picks = sorted.slice(0, 3)

    this.setData({
      foodList: enriched,
      dailyPicks: picks
    })
    this.applyFilters()
  },

  // ===== 分类筛选 =====
  onTagTap(e) {
    const tag = e.currentTarget.dataset.tag
    this.setData({ selectedTag: tag })
    this.applyFilters()
  },

  // ===== 排序切换 =====
  toggleSort() {
    if (this.data.sortBy === 'rate') {
      this.setData({ sortBy: 'price', sortLabel: '按价格排序' })
    } else {
      this.setData({ sortBy: 'rate', sortLabel: '按评分排序' })
    }
    this.applyFilters()
  },

  // ===== 核心筛选排序 =====
  applyFilters() {
    this.setData({ loading: true })
    let list = [...this.data.foodList]

    // 按标签过滤
    if (this.data.selectedTag !== '全部') {
      list = list.filter(f => f.tag === this.data.selectedTag)
    }

    // 排序
    if (this.data.sortBy === 'rate') {
      list.sort((a, b) => b.rate - a.rate)
    } else {
      list.sort((a, b) => parseFloat(a.price.slice(1)) - parseFloat(b.price.slice(1)))
    }

    setTimeout(() => {
      this.setData({ displayList: list, loading: false })
    }, 300)
  },

  // ===== 点击今日精选 → 跳转详情页 =====
  onFeaturedTap(e) {
    const food = e.currentTarget.dataset.food
    this.navigateToDetail(food)
  },

  // ===== 点击列表菜品 → 跳转详情页 =====
  onFoodTap(e) {
    const food = e.currentTarget.dataset.food
    this.navigateToDetail(food)
  },

  // ===== 跳转到菜品详情 =====
  navigateToDetail(food) {
    wx.navigateTo({
      url: `/pages/food-detail/food-detail?id=${food.id}&name=${food.name}&price=${food.price}&rate=${food.rate}&canteen=${food.canteen}&tag=${food.tag}&desc=${food.desc}&emoji=${food.emoji}`
    })
  },

  // ===== 返回首页 =====
  goBack() {
    wx.navigateBack()
  }
})
