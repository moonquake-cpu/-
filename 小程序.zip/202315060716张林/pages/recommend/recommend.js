const app = getApp()

Page({
  data: {
    searchValue: '',
    searchHistory: ['麻辣香锅', '意面', '奶茶', '披萨'],
    selectedTag: '全部',
    tagList: ['全部', '中餐', '西餐', '饮品', '日料', '甜品', '小吃'],
    sortBy: 'rate',
    sortLabel: '按评分排序',
    recommendList: [],
    filteredList: [],
    loading: false,
    showHistory: false
  },

  onLoad() {
    this.setData({ recommendList: app.globalData.foodList })
    this.applyFilters()
  },

  // ===== 搜索 =====
  onSearch(e) {
    const value = e.detail.trim()
    if (!value) return
    this.setData({ searchValue: value, showHistory: false })
    this.applyFilters()
    const history = this.data.searchHistory
    if (!history.includes(value)) {
      history.unshift(value)
      if (history.length > 6) history.pop()
      this.setData({ searchHistory: history })
    }
  },
  onSearchChange(e) {
    this.setData({ searchValue: e.detail })
  },
  onSearchFocus() {
    this.setData({ showHistory: true })
  },
  onSearchBlur() {
    setTimeout(() => this.setData({ showHistory: false }), 300)
  },
  onHistoryTap(e) {
    const keyword = e.currentTarget.dataset.keyword
    this.setData({ searchValue: keyword, showHistory: false })
    this.applyFilters()
  },
  clearHistory() {
    wx.showModal({
      title: '提示',
      content: '确定清空搜索历史？',
      success: (res) => {
        if (res.confirm) this.setData({ searchHistory: [] })
      }
    })
  },

  // ===== 标签筛选 =====
  onTagTap(e) {
    const tag = e.currentTarget.dataset.tag
    this.setData({ selectedTag: tag })
    this.applyFilters()
  },

  // ===== 切换排序 =====
  toggleSort() {
    if (this.data.sortBy === 'rate') {
      this.setData({ sortBy: 'price', sortLabel: '按价格排序' })
    } else {
      this.setData({ sortBy: 'rate', sortLabel: '按评分排序' })
    }
    this.applyFilters()
  },

  // ===== 核心筛选逻辑 =====
  applyFilters() {
    this.setData({ loading: true })
    let list = [...this.data.recommendList]
    if (this.data.searchValue.trim()) {
      const kw = this.data.searchValue.trim().toLowerCase()
      list = list.filter(f =>
        f.name.toLowerCase().includes(kw) ||
        f.canteen.toLowerCase().includes(kw) ||
        f.tag.toLowerCase().includes(kw)
      )
    }
    if (this.data.selectedTag !== '全部') {
      list = list.filter(f => f.tag === this.data.selectedTag)
    }
    if (this.data.sortBy === 'rate') {
      list.sort((a, b) => b.rate - a.rate)
    } else {
      list.sort((a, b) => parseFloat(a.price.slice(1)) - parseFloat(b.price.slice(1)))
    }
    setTimeout(() => {
      this.setData({ filteredList: list, loading: false })
    }, 300)
  },

  // ===== 点击推荐菜品 =====
  onRecommendTap(e) {
    const food = e.currentTarget.dataset.food
    wx.navigateTo({
      url: `/pages/index/index`,
      success: () => {
        wx.showToast({ title: `查看: ${food.name}`, icon: 'none' })
      }
    })
  },

  // ===== 随机推荐（交互API + 动画API） =====
  randomRecommend() {
    wx.showLoading({ title: '推荐计算中...' })
    const animation = wx.createAnimation({
      duration: 800,
      timingFunction: 'ease-in-out'
    })
    animation.rotate(360).scale(1.2).step()
    animation.rotate(0).scale(1).step()
    setTimeout(() => {
      wx.hideLoading()
      const list = this.data.filteredList.length > 0 ? this.data.filteredList : this.data.recommendList
      if (list.length === 0) {
        wx.showToast({ title: '暂无匹配美食', icon: 'none' })
        return
      }
      const random = list[Math.floor(Math.random() * list.length)]
      this.setData({ randomAnimation: animation.export() })
      wx.showModal({
        title: '🎯 为你推荐',
        content: `${random.name} — ${random.canteen}\n评分: ${'⭐'.repeat(Math.round(random.rate))}\n价格: ${random.price}`,
        confirmText: '去看看',
        success: (res) => {
          if (res.confirm) {
            wx.showToast({ title: `就去吃${random.name}!`, icon: 'success' })
          }
        }
      })
    }, 1000)
  },

  // ===== 音频API =====
  onVoiceGuide() {
    const audio = wx.createInnerAudioContext()
    audio.autoplay = true
    audio.onError(() => {
      wx.showToast({ title: '🎵 推荐：试试今日推荐的麻辣香锅！', icon: 'none', duration: 3000 })
    })
    this.audio = audio
    audio.src = '/audio/welcome.mp3'
  },

  onUnload() {
    if (this.audio) { this.audio.destroy() }
  }
})
