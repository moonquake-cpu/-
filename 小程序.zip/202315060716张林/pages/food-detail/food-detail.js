const app = getApp()

Page({
  data: {
    food: null,
    liked: false,
    // 精选评价
    reviews: [
      { user: '美食达人小王', text: '分量很足，味道绝了，每次来必点！' },
      { user: '吃货小李', text: '性价比超高，排队也值得等。' },
      { user: '学姐阿敏', text: '口味正宗，跟在老家吃的一个味儿~' }
    ],
    // 推荐理由库
    reasons: [
      '主厨特制配方，回头客最多，每日限量供应',
      '精选进口食材，口感出众，烹饪工艺讲究',
      '每日鲜榨现做，清爽解腻首选，健康无添加',
      '自选搭配自由度大，满足个性口味需求',
      '浓郁汤底熬制6小时以上，鲜香浓郁',
      '现点现做，分量超足，芝士拉丝效果绝佳'
    ]
  },

  onLoad(options) {
    // 从页面参数获取菜品ID
    const foodId = parseInt(options.id)
    let food = null

    // 先从缓存读取
    const cached = app.globalData.foodList
    if (cached && cached.length > 0) {
      food = cached.find(f => f.id === foodId)
    }

    // 缓存中没有则用传入参数构建
    if (!food && options.name) {
      food = {
        id: foodId,
        name: options.name || '',
        price: options.price || '',
        rate: parseFloat(options.rate) || 0,
        canteen: options.canteen || '',
        tag: options.tag || '',
        desc: options.desc || '',
        emoji: options.emoji || '🍽️',
        calories: 280 + Math.floor(Math.random() * 300),
        protein: 10 + Math.floor(Math.random() * 20),
        carbs: 30 + Math.floor(Math.random() * 30),
        fat: 5 + Math.floor(Math.random() * 15)
      }
    }

    if (!food) {
      wx.showToast({ title: '菜品不存在', icon: 'none' })
      setTimeout(() => wx.navigateBack(), 1500)
      return
    }

    // 添加推荐理由
    if (!food.reason) {
      food.reason = this.data.reasons[(foodId - 1) % this.data.reasons.length]
    }

    this.setData({ food })
  },

  // ===== 收藏 =====
  onLike() {
    const newLiked = !this.data.liked
    this.setData({ liked: newLiked })
    wx.showToast({
      title: newLiked ? '已收藏' : '已取消收藏',
      icon: newLiked ? 'success' : 'none'
    })
  },

  // ===== 分享 =====
  onShare() {
    wx.showShareMenu({
      withShareTicket: true,
      success: () => {
        wx.showToast({ title: '点击右上角分享给好友', icon: 'none' })
      }
    })
  },

  // ===== 点单 =====
  onOrder() {
    wx.showModal({
      title: '确认点单',
      content: `将跳转到${this.data.food.canteen}窗口下单\n菜品：${this.data.food.name}\n价格：${this.data.food.price}`,
      confirmText: '去下单',
      success: (res) => {
        if (res.confirm) {
          wx.showToast({ title: '跳转中...', icon: 'loading' })
          setTimeout(() => {
            wx.navigateBack()
          }, 1500)
        }
      }
    })
  },

  // ===== 分享 =====
  onShareAppMessage() {
    const food = this.data.food
    return {
      title: `${food.name} - 校园美食推荐`,
      path: `/pages/food-detail/food-detail?id=${food.id}&name=${food.name}&price=${food.price}&rate=${food.rate}&canteen=${food.canteen}&tag=${food.tag}&desc=${food.desc}&emoji=${food.emoji}`
    }
  }
})
